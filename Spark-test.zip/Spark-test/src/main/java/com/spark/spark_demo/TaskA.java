package com.spark.spark_demo;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import scala.Tuple2;

import java.util.Arrays;

public class TaskA {
public static void main(String[ ] args) {

	SparkConf config = new SparkConf () . setAppName("Word Count") . setMaster("local[*]");
	JavaSparkContext context = new JavaSparkContext(config);
	JavaRDD<String> rdd = context.textFile("src/main/resources/sample.txt");
	JavaRDD<String> rdd1 = rdd.flatMap(k -> Arrays.asList(k.split(" ")).iterator());
	
	JavaPairRDD<String, Integer> prdd1 = rdd1. mapToPair(k -> new Tuple2<String, Integer>(k, 1));
	JavaPairRDD<String, Integer> prdd2 = prdd1.reduceByKey((v1, v2) -> v1+v2);
	JavaPairRDD<Integer, String> prdd3 = prdd2. mapToPair (k -> new Tuple2<Integer, String>(k._2(), k._1()));
	JavaPairRDD<Integer, String> prdd4 = prdd3. sortByKey(false);
	
	prdd4.take(100).forEach(System.out::println);
	context.close();
	
}
}